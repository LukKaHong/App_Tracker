#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "psram.h"
#include "pmic.h"
#include "cpu.h"
#include "secureboot.h"
#include "aboot.h"
#include "reg.h"
#include "smux.h"
#include "property.h"
#include "efuse.h"
#include "syscall-arom.h"
#include "pmu.h"
#if defined(CPU_MODEL_CRANE)
#include "freq.h"
#include "mpu.h"
#endif

#define SUPPORT_DDR_MEMORY (AROM_VERSION == AROM_VER_2022_11_11_CRANEG_CR5 || \
                            AROM_VERSION == AROM_VER_2022_07_28_CRANEW_Z2 || \
                            AROM_VERSION == AROM_VER_2023_09_09_FULMAR_CR5)

#define SUPPORT_PSRAM_MEMORY (AROM_VERSION != AROM_VER_2022_11_11_CRANEG_CR5 && \
                              AROM_VERSION != AROM_VER_2024_04_30_LAPWING_CR5 && \
                              AROM_VERSION != AROM_VER_2023_09_09_FULMAR_CR5)
#if SUPPORT_DDR_MEMORY
#include "ddr.h"
#endif

#include "log.h"
#define LOG_MODULE "Preboot"
#define LOG_LEVEL LOG_LEVEL_MAIN

/*---------------------------------------------------------------------------*/
#define SUPPORT_BOOT_GO_TO_PRODUCTION   0
/*---------------------------------------------------------------------------*/
#if defined(CPU_MODEL_CRANE)
extern char __lzma_decode_start, __lzma_decode_size;
#endif

/*---------------------------------------------------------------------------*/
#define UMTI_BASE                 0xD4207000
#define USB_PHY_REG_04            0x10
#define USB_PHY_REG_25            0x94
#define USB_PHY_REG_28            0xA0
#define USB_PHY_REG_29            0xA4
#define HS_ISEL_MASK              (0x3 << 12)
#define HS_ISEL                   (0x3 << 12)
/*---------------------------------------------------------------------------*/
void
usb_phy_config(void)
{
  unsigned val;
  unsigned chip_id;

  chip_id = hw_chip_id();
  if(chip_id == CHIP_ID_CRANE) {
    /* driver strength */
    val = (unsigned)readl(UMTI_BASE + USB_PHY_REG_28);
    writel((val & ~HS_ISEL_MASK) | HS_ISEL, UMTI_BASE + USB_PHY_REG_28);
    LOG_PRINT("Usb phy reg 28 0x%x -> 0x%lx\n", val, readl(UMTI_BASE + USB_PHY_REG_28));
  } else if((CHIP_ID_CRANEG == chip_id) || (CHIP_ID_CRANEM == chip_id)) {
    val = (unsigned)readl(UMTI_BASE + USB_PHY_REG_29);
    writel((val & ~0x1F) | 0x1B, UMTI_BASE + USB_PHY_REG_29);
    LOG_PRINT("Usb phy reg 29 0x%x -> 0x%lx\n", val, readl(UMTI_BASE + USB_PHY_REG_29));
    val = (unsigned)readl(UMTI_BASE + USB_PHY_REG_25);
    writel(val | (BIT7), UMTI_BASE + USB_PHY_REG_25);
    val = (unsigned)readl(UMTI_BASE + USB_PHY_REG_04);
    writel(val | (BIT4 | BIT5 | BIT6), UMTI_BASE + USB_PHY_REG_04);
  }
}
/*---------------------------------------------------------------------------*/
#if defined(CPU_MODEL_CRANE) && (AROM_VERSION != AROM_VER_2024_04_30_LAPWING_CR5)
static void
psram_mpu_config(void)
{
#if SUPPORT_DDR_MEMORY
  extern char __ddr_base;
  unsigned base = (unsigned)&__ddr_base;
  unsigned size = get_ddr_size();
#else
  extern char __psram_base;
  unsigned base = (unsigned)&__psram_base;
  unsigned size = get_psram_size();
#endif

  mpu_region_config(ATCM_CODE_REGION_NUM, 0x0, 0x10000, MPU_ATTR_RWX);
  mpu_region_config(PSRAM_DDR_REGION_NUM_RWX, base, size, MPU_ATTR_RWX);
  mpu_region_config(PSRAM_DDR_REGION_NUM_NONE, 0x0, 0x80000000, MPU_ATTR_NONE);
}
#endif
/*---------------------------------------------------------------------------*/
int
main(void)
{
  /*read or write geu, must enable clk at first, else, geu bank dump always be 0. */
  geu_clk_enable();

#if defined(CPU_MODEL_CRANE)
  cr5_axi_set_max_freq();
#endif

  LOG_PRINT("Executing preboot application...\n");
  LOG_PRINT("Preboot version: %s\n", BOOTLOADER_VERSION);

  /* force init prop 1K space: 0XB0020C00~ 0xB0021000 */
  asr_property_area_init(1);
  asr_property_set("bl2.preboot.ver", BOOTLOADER_VERSION);

#if defined(CPU_MODEL_CRANE) || defined(CPU_MODEL_CRANEW_MCU)
#if (AROM_VERSION != AROM_VER_2022_08_08_CRANEW_CR5) && (AROM_VERSION != AROM_VER_2023_09_09_FULMAR_CR5)
  /* arom-crane alread print log, this is only for set prop */
  if(!fuse_trust_boot_enabled()) {
    /*LOG_PRINT("### Non-trusted boot mode. ###\n"); */
    asr_property_set("bl1.secureboot", "0");
  } else {
    /*LOG_PRINT("### Trusted boot mode. ###\n"); */
    asr_property_set("bl1.secureboot", "1");
  }
#else
  /*LOG_PRINT("### Non-trusted boot mode. ###\n"); */
  asr_property_set("bl1.secureboot", "0");
#endif

#if (AROM_VERSION != AROM_VER_2022_08_08_CRANEW_CR5) && (AROM_VERSION != AROM_VER_2023_09_09_FULMAR_CR5)
  /*
   * "halt": When download completed, if usb pull out, board powerdown. defaultly it is "halt",
   * "reboot": some customer want to reboot instead of powerdown, so customer set it to "reboot" manually.
   * "noaction": if vbus is unconnected, usb_connect() is 0.
   *             need set "noaction" to workaround the bug:
   *             After download, flasher judges that it is usb pulled out, enter forcedown by mistake.
   */
  asr_property_set("bl2.usb_disconnect", "halt");

  /* enter production mode after go(boot continue) if bl2.go_production is true */
#if SUPPORT_BOOT_GO_TO_PRODUCTION
  asr_property_set(PROP_NAME_GO_PRODUCTION, "true");
#endif

  usb_phy_config();

  fuse_read_lotid();

  if(hw_platform_type() == HW_PLATFORM_TYPE_SILICON) {
    pmic_setup();

    uint8_t powerup_reason = pmic_powerup_get_reason();
    LOG_PRINT("Power_up_reason=0x%x.\n", powerup_reason);

    pmic_fault_wu_en_disable();

    /* except bit6(ivbus_detect), bit1(exton1_wu_log) and bit0(onkey_wu_log), 0x67 = 0B 0100 0011 */
    if(!(powerup_reason & 0x67)) {
      LOG_WARN("Warning: power_up_reason=0x%x is abnormal.\n", powerup_reason);
      /* pmic_sw_pdown(); */
      /* return 0; */
    }

    switch(PMIC_PID(pmic_get_id())) {
    case PM802:
    case PM802S:
      /* workaround for PM802, if power up log = 0 or 8(bat_wu_log), pmic power down. PM813 no this hardware bug. */
      if(0 == powerup_reason || 8 == powerup_reason) {
        LOG_WARN("Warning: power_up_reason = 0 or 8(bat_wu_log). need pmic power down\n");
        pmic_sw_pdown();
        return 0;
      }
      break;
    case PM813L:
      /* pmic813L A0's bug: onkey reason cannot set bit in powerup_reason, So add workaround */
      break;
    default:
      break;
    }
  }
#endif
#endif

#if (SUPPORT_DDR_MEMORY)
  unsigned chip_id = hw_chip_id();
  if(chip_id == CHIP_ID_FULMAR || chip_id == CHIP_ID_CRANEGT) {
    ddr_init();
  }
#endif

#if (SUPPORT_PSRAM_MEMORY)
  psram_init();
#endif

#if defined(CPU_MODEL_CRANE)
#if (AROM_VERSION != AROM_VER_2024_04_30_LAPWING_CR5)
  psram_mpu_config();
#endif
  /*
   * Atcm 64K is not enough to parse bootloder volume, so update to psram.
   */
  LOG_INFO("Set fip image load address spaces to 0x%x\n",
           (unsigned)&__lzma_decode_start);
  sb_fip_image_setup((void *)&__lzma_decode_start, (unsigned)&__lzma_decode_size);
#endif

#if (AROM_VERSION == AROM_VER_2022_08_08_CRANEW_CR5) || (AROM_VERSION == AROM_VER_2023_09_09_FULMAR_CR5)
  uint32_t val = readl(CIU_BASE + SW_SCRATCH);
  val = (val & ~FLAGS_RUNNING_STAGE_MASK) | FLAGS_RUNNING_STAGE_PREBOOT_COMPLETE;
  writel(val, CIU_BASE + SW_SCRATCH);
  LOG_INFO("Set running stage: [0x%x] = 0x%x.\n", (CIU_BASE + SW_SCRATCH), (unsigned)readl(CIU_BASE + SW_SCRATCH));
#endif

  return 0;
}
/*---------------------------------------------------------------------------*/
